with open("output.txt", "r") as f:
    content = f.read()
    print("File content:")
    print(content)
