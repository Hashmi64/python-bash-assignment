with open("output.txt", "w") as f:
    f.write("This is a sample file.\nWritten using Python.")

print("File written successfully!")
